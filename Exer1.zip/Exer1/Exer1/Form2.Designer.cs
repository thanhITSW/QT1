﻿namespace Exer1
{
    partial class Oder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grp1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtOderID = new System.Windows.Forms.TextBox();
            this.txtOderDate = new System.Windows.Forms.TextBox();
            this.txtAgentID = new System.Windows.Forms.TextBox();
            this.bThem = new System.Windows.Forms.Button();
            this.bXoa = new System.Windows.Forms.Button();
            this.bSua = new System.Windows.Forms.Button();
            this.bLuu = new System.Windows.Forms.Button();
            this.bIn = new System.Windows.Forms.Button();
            this.bNhap = new System.Windows.Forms.Button();
            this.grd = new System.Windows.Forms.DataGridView();
            this.grp1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd)).BeginInit();
            this.SuspendLayout();
            // 
            // grp1
            // 
            this.grp1.Controls.Add(this.bNhap);
            this.grp1.Controls.Add(this.bIn);
            this.grp1.Controls.Add(this.bLuu);
            this.grp1.Controls.Add(this.bSua);
            this.grp1.Controls.Add(this.bXoa);
            this.grp1.Controls.Add(this.bThem);
            this.grp1.Controls.Add(this.txtAgentID);
            this.grp1.Controls.Add(this.txtOderDate);
            this.grp1.Controls.Add(this.txtOderID);
            this.grp1.Controls.Add(this.label3);
            this.grp1.Controls.Add(this.label2);
            this.grp1.Controls.Add(this.label1);
            this.grp1.Location = new System.Drawing.Point(12, 27);
            this.grp1.Name = "grp1";
            this.grp1.Size = new System.Drawing.Size(919, 284);
            this.grp1.TabIndex = 0;
            this.grp1.TabStop = false;
            this.grp1.Text = "Nhập thông tin";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "OderID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "OderDate";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 169);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "AgentID";
            // 
            // txtOderID
            // 
            this.txtOderID.Location = new System.Drawing.Point(155, 45);
            this.txtOderID.Name = "txtOderID";
            this.txtOderID.Size = new System.Drawing.Size(197, 26);
            this.txtOderID.TabIndex = 3;
            // 
            // txtOderDate
            // 
            this.txtOderDate.Location = new System.Drawing.Point(155, 111);
            this.txtOderDate.Name = "txtOderDate";
            this.txtOderDate.Size = new System.Drawing.Size(197, 26);
            this.txtOderDate.TabIndex = 4;
            // 
            // txtAgentID
            // 
            this.txtAgentID.Location = new System.Drawing.Point(156, 168);
            this.txtAgentID.Name = "txtAgentID";
            this.txtAgentID.Size = new System.Drawing.Size(196, 26);
            this.txtAgentID.TabIndex = 5;
            // 
            // bThem
            // 
            this.bThem.Location = new System.Drawing.Point(566, 37);
            this.bThem.Name = "bThem";
            this.bThem.Size = new System.Drawing.Size(127, 49);
            this.bThem.TabIndex = 6;
            this.bThem.Text = "Thêm";
            this.bThem.UseVisualStyleBackColor = true;
            this.bThem.Click += new System.EventHandler(this.bThem_Click);
            // 
            // bXoa
            // 
            this.bXoa.Location = new System.Drawing.Point(566, 102);
            this.bXoa.Name = "bXoa";
            this.bXoa.Size = new System.Drawing.Size(127, 45);
            this.bXoa.TabIndex = 7;
            this.bXoa.Text = "Xóa";
            this.bXoa.UseVisualStyleBackColor = true;
            // 
            // bSua
            // 
            this.bSua.Location = new System.Drawing.Point(566, 163);
            this.bSua.Name = "bSua";
            this.bSua.Size = new System.Drawing.Size(127, 37);
            this.bSua.TabIndex = 8;
            this.bSua.Text = "Sửa";
            this.bSua.UseVisualStyleBackColor = true;
            // 
            // bLuu
            // 
            this.bLuu.Location = new System.Drawing.Point(769, 37);
            this.bLuu.Name = "bLuu";
            this.bLuu.Size = new System.Drawing.Size(116, 49);
            this.bLuu.TabIndex = 9;
            this.bLuu.Text = "Lưu";
            this.bLuu.UseVisualStyleBackColor = true;
            this.bLuu.Click += new System.EventHandler(this.bLuu_Click);
            // 
            // bIn
            // 
            this.bIn.Location = new System.Drawing.Point(769, 102);
            this.bIn.Name = "bIn";
            this.bIn.Size = new System.Drawing.Size(116, 41);
            this.bIn.TabIndex = 10;
            this.bIn.Text = "In";
            this.bIn.UseVisualStyleBackColor = true;
            // 
            // bNhap
            // 
            this.bNhap.Location = new System.Drawing.Point(769, 163);
            this.bNhap.Name = "bNhap";
            this.bNhap.Size = new System.Drawing.Size(116, 58);
            this.bNhap.TabIndex = 11;
            this.bNhap.Text = "Nhập OderDetail";
            this.bNhap.UseVisualStyleBackColor = true;
            // 
            // grd
            // 
            this.grd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grd.Location = new System.Drawing.Point(12, 317);
            this.grd.Name = "grd";
            this.grd.RowHeadersWidth = 62;
            this.grd.RowTemplate.Height = 28;
            this.grd.Size = new System.Drawing.Size(919, 281);
            this.grd.TabIndex = 1;
            // 
            // Oder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PapayaWhip;
            this.ClientSize = new System.Drawing.Size(953, 625);
            this.Controls.Add(this.grd);
            this.Controls.Add(this.grp1);
            this.Name = "Oder";
            this.Text = "Oder";
            this.Load += new System.EventHandler(this.Oder_Load);
            this.grp1.ResumeLayout(false);
            this.grp1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grp1;
        private System.Windows.Forms.Button bNhap;
        private System.Windows.Forms.Button bIn;
        private System.Windows.Forms.Button bLuu;
        private System.Windows.Forms.Button bSua;
        private System.Windows.Forms.Button bXoa;
        private System.Windows.Forms.Button bThem;
        private System.Windows.Forms.TextBox txtAgentID;
        private System.Windows.Forms.TextBox txtOderDate;
        private System.Windows.Forms.TextBox txtOderID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView grd;
    }
}