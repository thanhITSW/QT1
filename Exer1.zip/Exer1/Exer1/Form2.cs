﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exer1
{
    public partial class Oder : Form
    {
        SqlConnection cn;
        SqlDataAdapter data;
        SqlCommand cm;
        DataTable tb;
        int dk = 0;
        public Oder()
        {
            InitializeComponent();
        }

        private void Oder_Load(object sender, EventArgs e)
        {
            string sql = "initial catalog = MyDatabase; data source = DESKTOP-0H7G9I2\\SQLEXPRESS; integrated security = true";
            cn = new SqlConnection(sql);
            cn.Open();

            formload();

        }
        void formload()
        {
            txtOderID.Enabled = false;
            txtOderDate.Enabled = false;
            txtAgentID.Enabled = false;
            htGRD();
        }
        public void enableGRP(GroupBox grp, bool b)
        {
            grp.Enabled = b;
        }

        private void bThem_Click(object sender, EventArgs e)
        {
            txtOderID.Enabled = true;
            txtOderDate.Enabled = true;
            txtAgentID.Enabled = true;
            txtOderID.Clear();
            txtOderDate.Clear();
            txtAgentID.Clear();
            txtOderID.Focus();
            bLuu.Enabled = true;
            dk = 1;
        }

        private void bLuu_Click(object sender, EventArgs e)
        {
            string s = "insert into Orderr values ('" + txtOderID.Text + "', N'" + txtOderDate.Text + "', '" + txtAgentID.Text + "')";
            cm = new SqlCommand(s, cn);
            cm.ExecuteNonQuery();
            formload();
        }
        void htGRD()
        {
            string s = "select * from Orderr";//cbkhoa.text
            data = new SqlDataAdapter(s, cn);
            tb = new DataTable();
            data.Fill(tb);
            grd.DataSource = tb;
        }
    }
}
