﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exer1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
     
        }
        public bool checkText()
        {
            if(txtTK.Text == "admin" && txtMK.Text == "123456")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void bLogin_Click(object sender, EventArgs e)
        {
            Oder oder = new Oder();
            if (checkText() == true)
            {
                oder.ShowDialog();
            }
            else
            {
                MessageBox.Show("Ban dang nhap sai. Vui long dang nhap lai");
                txtTK.Clear();
                txtMK.Clear();
            }
        }
    }
}
